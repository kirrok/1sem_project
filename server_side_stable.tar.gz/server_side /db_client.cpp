//
// Created by kirrok on 01.05.16.
//

#include <iostream>
#include <stdexcept>
#include <cstring>
#include "db_client.h"

unsigned long db_client::query(data &data_) throw(ss_exception) {

    if (data_.act_number == 0) {
        throw ss_exception("No activities select!");
    }

    std::string query_;
    query_ = "SELECT place_id, place_name, place_weather from appDB.place WHERE place.place_weather BETWEEN ";
    query_ += std::to_string(data_.lt);
    query_ += " AND ";
    query_ += std::to_string(data_.ut);
    query_ += " AND place_activity IN(";

    for (size_t i = 0; i < data_.act_number; i++) {

        if (i != data_.act_number - 1)
            query_ += std::to_string(data_.act[i]) + ",";
        else
            query_ += std::to_string(data_.act[i]);
    }
    query_ += ");";

    MYSQL *conn = mysql_init(NULL);
    if (conn == 0)
        throw ss_exception("Init database one");

    if (!mysql_real_connect(conn, host, user, password, name, port, socket, 0))
        throw ss_exception("Connection to database one");

    if (mysql_query(conn, query_.c_str())) {
        std::cout << mysql_error(conn) << std::endl;
        throw ss_exception("Query one");
    }
    res = mysql_store_result(conn);

    if (res == 0)
        throw ss_exception("Store results one");

    unsigned long rows_number = (unsigned long) mysql_num_rows(res);

    mysql_close(conn);

    return rows_number;
}

unsigned long db_client::query(std::string name_) throw(ss_exception) {

    std::string query_;
    query_ = "SELECT descr.descr_about, descr.descr_logo, descr.descr_activity, descr.descr_language, descr.descr_food, descr.descr_language, descr.descr_money "
            "FROM appDB.place_description as descr JOIN appDB.place as place ON descr.descr_place = place.place_id "
            "WHERE place.place_name = ";
    query_ += name_;
    query_ += ";";

    MYSQL *conn = mysql_init(NULL);
    if (conn == 0)
        throw ss_exception("Init database two");

    if (!mysql_real_connect(conn, host, user, password, name, port, socket, 0))
        throw ss_exception("Connection to database two");

    if (mysql_query(conn, query_.c_str()))
        throw ss_exception("Query two");

    res = mysql_store_result(conn);

    if (res == 0)
        throw ss_exception("Store results two");

    unsigned long rows_number = (unsigned long) mysql_num_rows(res);

    mysql_close(conn);

    return rows_number;
}
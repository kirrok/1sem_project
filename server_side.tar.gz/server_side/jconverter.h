//
// Created by kirrok on 01.05.16.
//

#ifndef SERVER_SIDE_JCONVERTER_H
#define SERVER_SIDE_JCONVERTER_H

#include <json/json.h>

class jconverter {
public:
    static int type(json_object *query);

    jconverter(json_object *j) : jstring(j) { };
protected:
    json_object *jstring;

};


#endif //SERVER_SIDE_JCONVERTER_H

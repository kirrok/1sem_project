//
// Created by kirrok on 01.05.16.
//

#ifndef SERVER_SIDE_APP_REQUEST_H
#define SERVER_SIDE_APP_REQUEST_H


#include <string>

class app_request {
public:
    app_request(int lt_, int ut_, int anum, int *activities_);
    ~app_request();
    std::string &build_query();

private:
    int lt;
    int ut;
    int activities_number;
    int *activities;
    std::string query;
};


#endif //SERVER_SIDE_APP_REQUEST_H

#include <iostream>
#include <json/json_object.h>
#include "jconverter.h"
#include "app_request.h"
#include "db_client.h"
#include "server.h"
#include <string.h>
#include <memory>

using namespace std;

int main() {

    server serv;
    serv.listen(5002, 5);

    while (1) {
        serv.accept();
        char* buf = serv.read();

        json_object *jquery = json_tokener_parse(buf);
        cout << " \nКонвертируем в json: " << json_object_to_json_string(jquery) << endl;

        jconverter converter(jquery);

        app_request ar;
        db_client db;
        json_object *response;

        if (converter.type() == 1) {
            data data_ = converter.convert_json_to_data_one();

            string query = ar.build_query_one(data_.lt, data_.ut, data_.act_number, data_.act);
            cout << "\nЗапрос который пойдет в базу:" << query << endl;

            unsigned long rows_number = db.query_(query);
            MYSQL_RES *res = db.get_res();

            response = converter.convert_db_response_to_json_one(res, rows_number);
            cout << "\n Json - ответ:  " << json_object_to_json_string(response) << endl << endl;

        } else if (converter.type() == 2) {
            int id = converter.convert_json_to_data_two();
            string query = ar.build_query_two(id);
            cout << "\nЗапрос который пойдет в базу:" << query << endl;

            unsigned long rows_number = db.query_(query);

            MYSQL_RES *res = db.get_res();

            response = converter.convert_db_response_to_json_two(res);

            cout << "\n Json - ответ: " << flush << json_object_to_json_string(response) << endl;

        } else {
            cout << "Incorrect request type!" << endl;
            continue;
        }

        serv.write(json_object_to_json_string(response), strlen(json_object_to_json_string(response)));
        serv.free_buf();
    }
    return 0;
}
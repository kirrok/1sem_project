#include <iostream>
#include <json/json_object.h>
#include "jconverter_one.h"
#include "app_request.h"
#include "db_client.h"


#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <memory>


void error(const char *msg) {
    perror(msg);
    exit(1);
}

using namespace std;

const int portno = 5002;

using namespace std;

int main() {

    /*
     * 1. получить json строку1
     * 2. передать ее в конвертер1
     * 3. передать в app-request
     * 4. передать в db.
     * 5. из db передать в конвертер.
     * 6. вернуть клиенту.
    */
    int sockfd, newsockfd;
    socklen_t clilent_addr_size;

    size_t *header = new size_t;

    sockaddr_in serv_addr, cli_addr;

    ssize_t n;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        error("ERROR opening socket");

    bzero((char *) &serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);

    if (bind(sockfd, (sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
        error("ERROR on binding");

    listen(sockfd, 5);
//////
    clilent_addr_size = sizeof(cli_addr);

    newsockfd = accept(sockfd, (sockaddr *) &cli_addr, &clilent_addr_size);

    if (newsockfd < 0)
        error("ERROR on accept");


    n = read(newsockfd, header, sizeof(size_t));
    if (n < 0) error("ERROR reading to socket");

    char *buffer = new char[*header];
    bzero(buffer, *header);

    n = read(newsockfd, buffer, sizeof(size_t));
    if (n < 0) error("ERROR reading to socket");
    json_object *jquery = json_tokener_parse(buffer);


    //1.
  /*  json_object *jquery = json_object_new_object();-
    json_object *jtype = json_object_new_int(1);
    json_object *jlt = json_object_new_int(-25);
    json_object *jut = json_object_new_int(11);
    json_object *jarray = json_object_new_array();

    json_object *jactivities[3];
    jactivities[0] = json_object_new_int(1);
    jactivities[1] = json_object_new_int(3);
    jactivities[2] = json_object_new_int(7);


    json_object_array_put_idx(jarray, 0, jactivities[0]);
    json_object_array_put_idx(jarray, 1, jactivities[1]);
    json_object_array_put_idx(jarray, 2, jactivities[2]);


    json_object_object_add(jquery, "type", jtype);
    json_object_object_add(jquery, "lt", jlt);
    json_object_object_add(jquery, "ut", jut);
    json_object_object_add(jquery, "act", jarray);
*/
    cout << "Получаем Json от клиента: \n" << json_object_to_json_string(jquery) << endl;
    //2.
    jconverter_one converter(jquery);
    data data_ = converter.convert_json_to_data();
    //3
    app_request ar(data_.lt, data_.ut, data_.act_number, data_.act);
    string query = ar.build_query();
    cout << "\nЗапрос который пойдет в базу:\n" << query<< endl << endl;

    //4
    db_client db;

    unsigned long rows_number = db.query_(query);
    MYSQL_RES *res = db.get_res();
    MYSQL_ROW row;

    cout << "Данные , пришедшие из базы:" << endl;

    //5
    city **cities = new city *[rows_number];

    for (int i = 0; i < rows_number; i++) {
        row = mysql_fetch_row(res);
        cities[i] = new city;
        cities[i]->city = row[0];
        cities[i]->weather = atoi(row[1]);
        std::cout << row[0] << ", " << row[1] << std::endl;
    }
    json_object *response = converter.convert_to_json(cities, rows_number);

    //6
    cout << "\nJson ответ клиенту:" << endl;
    cout << json_object_to_json_string(response) <<endl;

    n = write(newsockfd,json_object_to_json_string(response),strlen(json_object_to_json_string(response)));

    if (n < 0)
        error("ERROR reading to socket");

    close(newsockfd);
    close(sockfd);
    return 0;

}
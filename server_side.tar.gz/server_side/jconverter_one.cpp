//
// Created by kirrok on 01.05.16.
//

#include <iostream>
#include "jconverter_one.h"


data &jconverter_one::convert_json_to_data() {

    data_.lt = atoi(json_object_to_json_string(json_object_object_get(jstring, "lt")));
    data_.ut = atoi(json_object_to_json_string(json_object_object_get(jstring, "ut")));
    json_object *jarray = json_object_object_get(jstring, "act");
    data_.act_number = json_object_array_length(jarray);
    data_.act = new int[data_.act_number];
    for (int i = 0; i < data_.act_number; i++) {
        data_.act[i] = atoi(json_object_to_json_string(json_object_array_get_idx(jarray, i)));
    }
    return data_;
}

jconverter_one::~jconverter_one() {
    delete[] data_.act;
}

json_object* jconverter_one::convert_to_json(city **cities_set, unsigned long number) {

    jresult = json_object_new_array();
    json_object *jstruct[number];
    json_object *jname;
    json_object *jweather;
    city *city_;
    for (int i = 0; i < number; i++) {
        jstruct[i] = json_object_new_object();
        city_ = cities_set[i];
        jname = json_object_new_string(city_->city);
        jweather = json_object_new_int(city_->weather);

        json_object_object_add(jstruct[i], "name", jname);
        json_object_object_add(jstruct[i], "weather", jweather);

        json_object_array_put_idx(jresult, i, jstruct[i]);

        }

    return jresult;
}

//
// Created by kirrok on 08.05.16.
//

#include <iostream>
#include "jconverter.h"
#include "server.h"


#include <string.h>
#include <memory>

using namespace std;

void server::listen(int port, int queue_size) {

    sockaddr_in serv_addr;

    main_sock = socket(AF_INET, SOCK_STREAM, 0);

    if (main_sock < 0)
        error("ERROR opening socket");

    int t = 1;

    setsockopt(main_sock, SOL_SOCKET, SO_REUSEADDR, &t, sizeof(int));

    bzero((char *) &serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);

    if (::bind(main_sock, (sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
        error("ERROR on binding");

    ::listen(main_sock, queue_size);

    cout << "СЛУШАЮ!" << endl;
}


void server::error(const char *msg) {
    cerr << msg << endl;
    exit(1);
}

char* server::read() {
    int already_read = 0;
    int header_size = sizeof(int);
    int *header = new int;

    bzero(header, header_size);

    int n;

    while (already_read < header_size) {

        n = ::read(client_sock, header, header_size - already_read);
        already_read += n;
    }
    if (n < 0) error("ERROR reading header from socket");

    cout << "Получили от клиента длину: " << *header << endl;

    already_read = 0;

    buf = new char[*header + 1];

    bzero(buf, *header + 1);

    while (already_read < *header) {
        n = ::read(client_sock, buf, *header);
        already_read += n;
    }

    if (n < 0) error("ERROR reading data from socket");
    cout << "\nПолучили от клиента строку:" << buf<< endl;


    return buf;

}

void server::accept() {
    socklen_t clilent_addr_size;
    sockaddr_in cli_addr;

    clilent_addr_size = sizeof(cli_addr);
    client_sock = ::accept(main_sock, (sockaddr *) &cli_addr, &clilent_addr_size);

    if (client_sock < 0)
        error("ERROR on accept");
}

void server::write(const char *data, int size) {

    int header_size = sizeof(int);
    int *header = new int;
    int already_written = 0;

    *header = size;

    int n;
    while (already_written < header_size) {

        n = ::write(client_sock, header, header_size - already_written);
        already_written += n;
    }
    if (n < 0) error("ERROR write header to socket");

    already_written = 0;

    while (already_written < *header) {
        n = ::write(client_sock, data, *header);
        already_written += n;
    }

    if (n < 0) error("ERROR write response to socket");

}


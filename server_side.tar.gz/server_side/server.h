//
// Created by kirrok on 08.05.16.
//

#ifndef SERVER_SIDE_SERVER_H
#define SERVER_SIDE_SERVER_H

#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>


class server {
public:
    server() : main_sock(-1) { };

    ~server() { if (main_sock > 0) close(main_sock); }

    void listen(int port, int queue_size);

    void accept();

    char* read();

    void write(const char *data, int size);

    void error(const char *msg);

    void set_rcv_timeout(int sec, int microsec) throw(std::exception);
    void free_buf() {
        delete[] buf;
    }
private:
    int main_sock;
    int client_sock;
    char *buf;
};

#endif //SERVER_SIDE_SERVER_H

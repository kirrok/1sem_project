//
// Created by kirrok on 01.05.16.
//

#include "jconverter.h"

int jconverter::type(json_object *query) {
    return atoi(json_object_to_json_string(json_object_object_get(query, "type")));
}

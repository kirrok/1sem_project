//
// Created by kirrok on 01.05.16.
//

#ifndef SERVER_SIDE_JCONVERTER_ONE_H
#define SERVER_SIDE_JCONVERTER_ONE_H

#include "jconverter.h"


struct data {
    int lt, ut, *act, act_number;
};
struct city {
    char *city;
    int weather;
};
class jconverter_one : public jconverter {
public:

    jconverter_one(json_object *j) : jconverter(j) { };

    ~jconverter_one();

    data& convert_json_to_data();
    json_object* convert_to_json(city **cities_set, unsigned long number);

private:
    json_object *jresult;
    data data_;
};



#endif //SERVER_SIDE_JCONVERTER_ONE_H
